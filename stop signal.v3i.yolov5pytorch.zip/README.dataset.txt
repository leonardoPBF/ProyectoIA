# stop signal > 2024-10-31 7:41pm
https://universe.roboflow.com/signal-stop/stop-signal

Provided by a Roboflow user
License: CC BY 4.0

